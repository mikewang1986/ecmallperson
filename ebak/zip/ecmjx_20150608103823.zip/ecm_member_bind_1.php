<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecm_member_bind`;");
E_C("CREATE TABLE `ecm_member_bind` (
  `openid` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `app` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `ecm_member_bind` values('DB6EC8DA55C144BBEDC2E28468B06EEF','601','qq');");
E_D("replace into `ecm_member_bind` values('1B917E18FFCAC250650E7A7C914EDEC3','602','qq');");
E_D("replace into `ecm_member_bind` values('E142B8B08B3CC3FA4B64B3DD43F1F5D2','604','qq');");
E_D("replace into `ecm_member_bind` values('FCE14BA28B2A51B20541936949748174','606','qq');");
E_D("replace into `ecm_member_bind` values('2.00Pf5CpB3ph8pB6828eb6d73xCb1lD','608','xwb');");
E_D("replace into `ecm_member_bind` values('E016AE803F077A883EB66617A31B85B8','613','qq');");
E_D("replace into `ecm_member_bind` values('4E0AED110A398A2D6C5F252C461D4064','615','qq');");
E_D("replace into `ecm_member_bind` values('53BF2A642BB56190DD2E65DFB2DCD745','618','qq');");
E_D("replace into `ecm_member_bind` values('4FDBDFA4747DAA0123E2005590924E05','619','qq');");
E_D("replace into `ecm_member_bind` values('7F22130FD8BD87B93A55DAFF59B7491B','621','qq');");
E_D("replace into `ecm_member_bind` values('D7F0EF2CE0CD5E93706BCFCBE777EA71','625','qq');");
E_D("replace into `ecm_member_bind` values('1A933E7269EA2FBDA9DF3E0319B010A4','626','qq');");
E_D("replace into `ecm_member_bind` values('0677A711F2E7B955345EAD6FFDDE5CBA','627','qq');");
E_D("replace into `ecm_member_bind` values('A511B1C7AD798AB88C292DE07E32D625','631','qq');");
E_D("replace into `ecm_member_bind` values('CCC011E9A8465F4B1E01C30E5826894D','642','qq');");
E_D("replace into `ecm_member_bind` values('1AA71F9ED52A1B92EFEAB058C07EE2DD','646','qq');");
E_D("replace into `ecm_member_bind` values('4C01AF370D768C04D6A58A360DDEA09F','648','qq');");
E_D("replace into `ecm_member_bind` values('512F199DE914696086B2CCB04501045A','651','qq');");
E_D("replace into `ecm_member_bind` values('D363E49E844C3F700F8E944BCC75362C','656','qq');");
E_D("replace into `ecm_member_bind` values('1591DDE9F9DE19F103CE90EDC7272E98','658','qq');");
E_D("replace into `ecm_member_bind` values('588D2CA9524719E2C0EC877E9FC63A39','669','qq');");
E_D("replace into `ecm_member_bind` values('D0EE900156F3C01298277E6D15E0C245','670','qq');");
E_D("replace into `ecm_member_bind` values('21D7523952D57C4A91B5AC652656F1A0','672','qq');");
E_D("replace into `ecm_member_bind` values('F8BE82AE3DFA7C3B8E7B6CA2619B0951','676','qq');");
E_D("replace into `ecm_member_bind` values('11D96726D891A1517E269D34BADED515','678','qq');");
E_D("replace into `ecm_member_bind` values('35959CAAF39E613FBBA85DDFCFD66026','679','qq');");
E_D("replace into `ecm_member_bind` values('2DA4CB94431297FC2A76701AD73B7D3D','681','qq');");
E_D("replace into `ecm_member_bind` values('0BD201A1444D615F2F1A382A88365EAC','682','qq');");
E_D("replace into `ecm_member_bind` values('10916B896B965DDA6F039F23A8C8EEBE','0','qq');");
E_D("replace into `ecm_member_bind` values('A53D8F9C8BED963A496ED1A2BC4CEFDC','688','qq');");
E_D("replace into `ecm_member_bind` values('9922363E3AAFF59CE7507C470E25B0B2','689','qq');");
E_D("replace into `ecm_member_bind` values('5FC4043B87EFBCF14E040219DEFFD386','690','qq');");
E_D("replace into `ecm_member_bind` values('9987DF2B49AA329DA4FE86CF75CB7331','691','qq');");
E_D("replace into `ecm_member_bind` values('56850930A06B488F6BBF6BCF32360625','692','qq');");
E_D("replace into `ecm_member_bind` values('A7B188810CA4EF8F14C4ED3CA81B5EA0','695','qq');");
E_D("replace into `ecm_member_bind` values('C9570C100B3B91810E49A40E0AEDFC95','696','qq');");
E_D("replace into `ecm_member_bind` values('B298BC76187B75BBE2F2B7D9BAF9DA2B','697','qq');");
E_D("replace into `ecm_member_bind` values('8BFD79317BB8803B29975784D6B5CA88','698','qq');");
E_D("replace into `ecm_member_bind` values('36FDACA3FAA17957692EE458E653F303','705','qq');");
E_D("replace into `ecm_member_bind` values('79CA8794A607B5BFFD5339D2617E3D55','708','qq');");
E_D("replace into `ecm_member_bind` values('46175B7BDD405D13052985CC2ED94B93','717','qq');");
E_D("replace into `ecm_member_bind` values('E5F22B8D292C2E4235B484E697794A7E','718','qq');");
E_D("replace into `ecm_member_bind` values('2.00DOKlGC3ph8pBb3b74c8cdc0sGD_T','726','xwb');");
E_D("replace into `ecm_member_bind` values('83CD12DA2A2A5A7F68CB82C704863475','728','qq');");
E_D("replace into `ecm_member_bind` values('DDA3EB3BFD6B68D163827BA9690BA557','729','qq');");
E_D("replace into `ecm_member_bind` values('2D0E8795104823FEF86CE091A5735287','730','qq');");
E_D("replace into `ecm_member_bind` values('DC79163870D92DDC002CBD8B5B729C78','734','qq');");
E_D("replace into `ecm_member_bind` values('AD0FACE2C72A65D970EFF2F3755E7EB0','736','qq');");
E_D("replace into `ecm_member_bind` values('2.00DOKlGC3ph8pBccdaf797260jq91o','741','xwb');");
E_D("replace into `ecm_member_bind` values('79ED14FF14500D340EC31E1E57FC27F2','748','qq');");
E_D("replace into `ecm_member_bind` values('791F29D800CF8E3E865F797A5C756D62','752','qq');");
E_D("replace into `ecm_member_bind` values('562CE1483F8D319DDF4CCBE772756AF0','754','qq');");
E_D("replace into `ecm_member_bind` values('1D712A0D4A0E6F5237025502A3DF1C8D','759','qq');");
E_D("replace into `ecm_member_bind` values('903B635D7B790AC8D0B6981B66BB4150','768','qq');");
E_D("replace into `ecm_member_bind` values('6E9BD51AD3609446D42A17B208C697FC','769','qq');");
E_D("replace into `ecm_member_bind` values('1EBD1D82854AC77BE62DDFC4BF97113E','770','qq');");
E_D("replace into `ecm_member_bind` values('7B0657BE7B2A7ABC58DFAD642A67FB92','772','qq');");
E_D("replace into `ecm_member_bind` values('DD130F7534759395D7127A3C846610A0','777','qq');");
E_D("replace into `ecm_member_bind` values('F30B4E91080066736E108E6AF61B00A7','786','qq');");
E_D("replace into `ecm_member_bind` values('B0359F885D3DC29BE70B9F2570F66383','800','qq');");
E_D("replace into `ecm_member_bind` values('94916E0D1F3FA998AC5BFD76C676EAB7','803','qq');");
E_D("replace into `ecm_member_bind` values('38D8BE14970F306B15F9D6BB75DADCED','809','qq');");
E_D("replace into `ecm_member_bind` values('45C4B3327812D378E73F92AC8DB51B4B','810','qq');");
E_D("replace into `ecm_member_bind` values('9354F4D3E3E46B08FD12AE69DD44300E','811','qq');");
E_D("replace into `ecm_member_bind` values('9BFA14E63DD07A466303AD30E106BD30','818','qq');");
E_D("replace into `ecm_member_bind` values('B1B84EA20A07FD86AAE2E9AAF13C8262','819','qq');");
E_D("replace into `ecm_member_bind` values('960BA622148DE75744F49E09367C271C','821','qq');");
E_D("replace into `ecm_member_bind` values('6FCBE85E07981871288F1E3CAB577472','831','qq');");
E_D("replace into `ecm_member_bind` values('C569EBE3915D54EEE598ACA10CCC3838','832','qq');");
E_D("replace into `ecm_member_bind` values('6D6BFAB3EDBDB13116697F870E754049','835','qq');");
E_D("replace into `ecm_member_bind` values('49A861874980FDA9B0A2395470B4AD3B','836','qq');");
E_D("replace into `ecm_member_bind` values('E4DAF376C106F73AE62AE1D38998BEEC','839','qq');");
E_D("replace into `ecm_member_bind` values('36D0D809FC39DE38F1A6F1CEB5896FDD','841','qq');");
E_D("replace into `ecm_member_bind` values('AB9EFC93ADE40E239C82B52505D7A82D','842','qq');");
E_D("replace into `ecm_member_bind` values('D202EB5B70724896E6BB4C57FD760081','844','qq');");
E_D("replace into `ecm_member_bind` values('34A89139EC9799915B36079D70DAF727','845','qq');");
E_D("replace into `ecm_member_bind` values('1ADEF0F3AE2010DF2B85A6576664BF7E','849','qq');");
E_D("replace into `ecm_member_bind` values('7E91EB11559ED09E4E230CBD3FDAB98F','17','qq');");
E_D("replace into `ecm_member_bind` values('07D55D9AA9D29E8C6BBE8AA9E72ACD48','19','qq');");
E_D("replace into `ecm_member_bind` values('E8C8F168D12A6A820119B78A6EAA67AB','4','qq');");

require("../../inc/footer.php");
?>